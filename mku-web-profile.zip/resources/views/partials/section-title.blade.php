<span class="block w-40 h-1.5 bg-gray-500 rounded-full mb-2"></span>
<h2 class="text-gray-900 font-bold text-3xl">{{ $text }}</h2>