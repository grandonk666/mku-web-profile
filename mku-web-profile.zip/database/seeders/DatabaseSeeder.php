<?php

namespace Database\Seeders;

use App\Models\Dosen;
use App\Models\Kategori;
use App\Models\Matakuliah;
use App\Models\Post;
use App\Models\StrukturOrganisasi;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            "name" => "Grandonk",
            "email" => "grandonk.cm@gmail.com",
            "password" => bcrypt("66666666")
        ]);

        Matakuliah::create([
            "nama" => "Bahasa Indonesia",
            "slug" => "bahasa-indonesia",
            "detail" => "<div>Eos non mollitia asperiores maiores. Sit natus possimus reiciendis accusamus quo. Quis quaerat magni non qui sequi atque cupiditate quis.</div>"
        ]);
        Matakuliah::create([
            "nama" => "Pancasila",
            "slug" => "pancasila",
            "detail" => "<div>Eos non mollitia asperiores maiores. Sit natus possimus reiciendis accusamus quo. Quis quaerat magni non qui sequi atque cupiditate quis.</div>"
        ]);
        Matakuliah::create([
            "nama" => "Kewarganegaraan",
            "slug" => "kewarganegaraan",
            "detail" => "<div>Eos non mollitia asperiores maiores. Sit natus possimus reiciendis accusamus quo. Quis quaerat magni non qui sequi atque cupiditate quis.</div>"
        ]);
        Matakuliah::create([
            "nama" => "Bahasa Inggris",
            "slug" => "bahasa-inggris",
            "detail" => "<div>Eos non mollitia asperiores maiores. Sit natus possimus reiciendis accusamus quo. Quis quaerat magni non qui sequi atque cupiditate quis.</div>"
        ]);

        Dosen::factory()->count(10)->create();

        StrukturOrganisasi::create([
            "jabatan" => "Koordinator",
            "dosen_id" => 1
        ]);
        StrukturOrganisasi::create([
            "jabatan" => "Wakil Koordinator",
            "dosen_id" => 2
        ]);
        StrukturOrganisasi::create([
            "jabatan" => "Kepala Laboratorium",
            "dosen_id" => 3
        ]);
        StrukturOrganisasi::create([
            "jabatan" => "Ketua Redaksi",
            "dosen_id" => 4
        ]);

        Kategori::create([
            "nama" => "Berita",
            "slug" => "berita"
        ]);
        Kategori::create([
            "nama" => "Pengumuman",
            "slug" => "pengumuman"
        ]);

        Post::factory()->count(20)->create();

        $post = Post::find(1);

        $post->attachments()->create([
            'filename' => 'attachment/gambar.jpg',
        ]);
    }
}
