

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("matakuliah-hero.jpg"),
  "keywords" => "mku, matakuliah, upn, jatim" . $matakuliah->nama,
  "description" => "Data Matakuliah yang ada di Matakuliah Umum Universitas
  Pembangunan Nasional Veteran Jawa Timur",
  "article" => true
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => $title,
  "image" => asset("matakuliah-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main
    class="container mx-auto min-h-screen py-12 px-4 flex justify-between items-start gap-6 flex-col md:flex-row">
    <div class="w-full md:w-[70%] min-h-screen bg-white rounded shadow-md p-4">
      <div class="w-full border-b-2 border-gray-800 flex items-center py-1 mb-4">
        <p class="leading-5 font-bold text-blue-600 uppercase px-2">
          <a href="<?php echo e(route('matakuliah.index')); ?>" class="hover:underline">
            Matakuliah
          </a>
        </p>
        <time
          class="text-sm leading-5 text-gray-500 lining-nums px-2 border-l-2 border-gray-800"
          datetime="<?php echo e($matakuliah->created_at->format('Y-m-d')); ?>">
          <?php echo e($matakuliah->created_at->format('d M Y')); ?>

        </time>
      </div>
      <div class="p-2">
        <h2 class="text-3xl font-bold mb-4"><?php echo e($title); ?></h2>
        <article class="prose max-w-none">
          <?php echo $matakuliah->detail; ?>

        </article>
      </div>
    </div>
    <div
      class="w-full md:w-[30%] bg-white rounded shadow-md overflow-hidden sticky top-20">
      <a href="<?php echo e(route('matakuliah.index')); ?>"
        class="block text-center text-2xl font-bold text-white px-6 py-4 bg-gray-500">
        Matakuliah lain
      </a>
      <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full p-4 border-t border-gray-500">
          <a href="<?php echo e(route('matakuliah.show', $matakuliah)); ?>"
            class="text-lg hover:text-blue-500 hover:underline">
            <?php echo e($matakuliah->nama); ?>

          </a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/matakuliah/show.blade.php ENDPATH**/ ?>