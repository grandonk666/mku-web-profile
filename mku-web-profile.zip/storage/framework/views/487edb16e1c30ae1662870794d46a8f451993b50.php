

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("matakuliah-hero.jpg"),
  "keywords" => "mku, matakuliah, upn, jatim",
  "description" => "Data Matakuliah yang ada di Matakuliah Umum Universitas
  Pembangunan Nasional Veteran Jawa Timur"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => "Data Matakuliah",
  "image" => asset("matakuliah-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="container mx-auto min-h-screen py-12 px-4">
    <div class="mb-10">
      <?php echo $__env->make("partials.section-title", ["text" => "Daftar Matakuliah MKU"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="flex justify-between md:px-6 items-center flex-wrap gap-10">
      <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.matakuliah-card', [
        'route' => route('matakuliah.show', $matakuliah),
        'headerText' => 'Matakuliah',
        'bodyText' => $matakuliah->nama,
        'icon' => 'fa-book'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/matakuliah/index.blade.php ENDPATH**/ ?>