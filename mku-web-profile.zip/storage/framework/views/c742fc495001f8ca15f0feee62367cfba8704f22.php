

<?php $__env->startSection("content"); ?>

<form method="POST" action="<?php echo e(route("admin.struktur.update", $struktur)); ?>"
  class="p-3 md:p-10 bg-white rounded shadow-md w-full mb-4">
  <?php echo method_field("put"); ?>
  <?php echo csrf_field(); ?>

  <div class="mb-4">
    <label class="block text-sm text-gray-700" for="jabatan">Nama
      Jabatan</label>
    <input
      class="w-full px-5 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 border-gray-200 focus:border-gray-800 <?php $__errorArgs = ["
      jabatan"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jabatan" name="jabatan"
      type="text" placeholder="Nama Jabatan" aria-label="Jabatan"
      value="<?php echo e(old("jabatan", $struktur->jabatan)); ?>">
    <?php $__errorArgs = ["jabatan"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="mb-6">
    <label class="block text-sm text-gray-700" for="dosen_id">Dosen</label>
    <select
      class="w-full px-5 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 border-gray-200 focus:border-gray-800 <?php $__errorArgs = ["
      dosen_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dosen_id" id="dosen_id">
      <option value=""> -- Pilih Dosen -- </option>
      <?php $__currentLoopData = $listDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(old("dosen_id", $struktur->dosen->id) == $dosen->id): ?>
      <option value="<?php echo e($dosen->id); ?>" selected><?php echo e($dosen->nama); ?></option>
      <?php else: ?>
      <option value="<?php echo e($dosen->id); ?>"><?php echo e($dosen->nama); ?></option>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ["dosen_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="flex gap-3">
    <button
      class="px-4 py-1 text-white font-light tracking-wider bg-blue-600 hover:bg-blue-500 rounded"
      type="submit">Simpan Perubahan</button>

    <a href="<?php echo e(route("admin.struktur.index")); ?>"
      class="px-4 py-1 text-white font-light tracking-wider bg-gray-700 hover:bg-gray-600 rounded">Batal</a>
  </div>
</form>


<form action="<?php echo e(route("admin.struktur.destroy", $struktur)); ?>" method="post">
  <?php echo method_field("delete"); ?>
  <?php echo csrf_field(); ?>

  <button onclick="return confirm('Anda Yakin Ingin Menghapus ?')"
    class="bg-red-500 text-white font-semibold py-2 px-3 rounded-br-md rounded-bl-md rounded-tr-md shadow hover:shadow-lg hover:bg-red-400">
    <i class="fas fa-trash mr-3"></i> Hapus Jabatan
  </button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/struktur/edit.blade.php ENDPATH**/ ?>