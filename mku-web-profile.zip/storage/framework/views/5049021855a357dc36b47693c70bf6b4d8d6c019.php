

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("matakuliah-hero.jpg"),
  "keywords" => "mku, matakuliah, upn, jatim",
  "description" => "Data Matakuliah yang ada di Matakuliah Umum Universitas
  Pembangunan Nasional Veteran Jawa Timur"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => "Data Matakuliah",
  "image" => asset("matakuliah-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="container mx-auto min-h-screen py-12 px-4">
    <div class="mb-10">
      <?php echo $__env->make("partials.section-title", ["text" => "Daftar Matakuliah MKU"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="flex justify-between md:px-6 items-center flex-wrap gap-10">
      <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
          class="w-full md:w-[45%] px-4 pt-3 pb-2 bg-white rounded shadow-md relative">
          <span
            class="w-16 h-16 rounded-full absolute right-6 -top-8 bg-white flex justify-center items-center border-8 border-gray-100 text-2xl text-gray-700">
            <i class="fas fa-book"></i>
          </span>
          <p class="text-sm font-bold py-1 border-b-2 border-gray-200">
            Matakuliah
          </p>
          <h2 class="text-xl font-light py-1">
            <?php echo e($matakuliah->nama); ?>

          </h2>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/matakuliah.blade.php ENDPATH**/ ?>