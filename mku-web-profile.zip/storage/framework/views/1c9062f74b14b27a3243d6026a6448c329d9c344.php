
<?php $__env->startSection("content"); ?>

<div class="relative w-full min-h-screen flex justify-center items-center bg-cover bg-bottom" style="background-image: url(<?php echo e(asset("home-hero.jpg")); ?>)">
  <div class="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent bg-black/30 flex justify-center items-center flex-col">
    <h1 class="text-6xl font-bold text-white text-center">Mata Kuliah Umum</h1>
    <span class="text-6xl font-bold text-white text-center">UPN “Veteran” Jawa Timur</span>
  </div>
</div>
<div class="container mx-auto min-h-screen py-10 px-6">
  <div class="mb-6">
    <span class="block w-40 h-1.5 bg-gray-700 rounded-full mb-2"></span>
    <h2 class="text-gray-800 font-bold text-3xl">Berita & Pengumuman</h2>
  </div>

  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="shadow-md flex flex-wrap w-full md:h-64 mb-10 rounded-md overflow-hidden">
    <?php if($post->sampul): ?>
    <div class="bg-cover bg-bottom border w-full md:w-2/5 h-52 md:h-full relative" style="background-image:url('<?php echo e(asset("storage/".$post->sampul)); ?>')">
    </div>  
    <?php else: ?>
    <div class="bg-cover bg-bottom border w-full md:w-2/5 h-52 md:h-full relative" style="background-image:url('<?php echo e(asset("storage/sampul-post/sampul-default.jpg")); ?>')">
    </div>  
    <?php endif; ?>
    
    <div class="bg-white w-full md:w-3/5 h-full md:border-t-8 border-gray-200">
      <div class="h-full mx-auto px-4 md:px-0 md:pt-10 md:-ml-28 relative">
        <div class="bg-white h-full p-6 -mt-24 md:mt-0 relative md:mb-0 flex flex-col items-center justify-between">
          <div class="w-full text-center md:text-left">
            <h3 class="text-xl font-bold"><?php echo e($post->judul); ?></h3>
            <p class="mb-0 mt-1 text-gray-700 text-sm uppercase">
              <?php echo e($post->kategori->nama); ?> - <span class="text-gray-500 italic capitalize"><?php echo e($post->created_at->format('d, M Y')); ?></span>
            </p>
            <hr class="w-1/4 md:ml-0 mt-2 border">
          </div>
          
          <div class="w-full">
            <p class="text-md mt-3 text-justify md:text-left text-sm text-gray-700">
              <?php echo e($post->excerpt); ?>

            </p>
          </div>
          
          <div class="w-full mt-4 text-center md:text-left">
            <a href="#" class="text-gray-500 text-sm">Lanjut Baca >></a>
          </div>
        </div>
      </div>
    </div>
  </div>  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/home.blade.php ENDPATH**/ ?>