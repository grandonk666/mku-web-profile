

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("dosen-hero.jpg"),
  "keywords" => "mku, dosen, upn, jatim",
  "description" => "Data Dosen Matakuliah Umum Universitas Pembangunan Nasional
  Veteran Jawa Timur"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => $title,
  "image" => asset("dosen-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="container mx-auto min-h-screen py-12 px-4">
    <div class="mb-10">
      <?php echo $__env->make("partials.section-title", ["text" => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="flex justify-center items-stretch flex-wrap gap-10">
      <?php $__empty_1 = true; $__currentLoopData = $listDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo $__env->make("partials.foto-dosen", [
        "dosen" => $dosen,
        "width" => "w-11/12 md:w-[28%]"
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2 class="text-4xl font-bold">Belum Ada Dosen Pengajar</h2>
      <?php endif; ?>
    </div>

  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/dosen/show.blade.php ENDPATH**/ ?>