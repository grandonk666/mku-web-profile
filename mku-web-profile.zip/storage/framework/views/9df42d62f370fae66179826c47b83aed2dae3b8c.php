

<?php $__env->startSection('content'); ?>

  <form method="POST" action="<?php echo e(route('admin.dosen.update', $dosen)); ?>"
    enctype="multipart/form-data"
    class="p-3 md:p-10 bg-white rounded shadow-md w-full mb-4">
    <?php echo method_field("put"); ?>
    <?php echo csrf_field(); ?>

    <div class="mb-6">
      <label class="block text-sm text-gray-700" for="nama">Nama</label>
      <input
        class="w-full px-5 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 focus:border-gray-800
      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        id="nama" name="nama" type="text" placeholder="Nama Dosen"
        aria-label="nama" value="<?php echo e(old('nama', $dosen->nama)); ?>">
      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-6">
      <label class="block text-sm text-gray-700" for="matakuliah_id">
        Matakuliah <span class="text-xs text-gray-500">(Boleh Kosong)</span>
      </label>
      <select
        class="w-full px-5 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 
      focus:border-gray-800 <?php $__errorArgs = ['matakuliah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        name="matakuliah_id" id="matakuliah_id">
        <option value=""> -- Pilih Matakuliah -- </option>
        <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($dosen->matakuliah && old('matakuliah_id', $dosen->matakuliah->id) == $matakuliah->id): ?>
            <option value="<?php echo e($matakuliah->id); ?>" selected>
              <?php echo e($matakuliah->nama); ?>

            </option>
          <?php else: ?>
            <option value="<?php echo e($matakuliah->id); ?>"><?php echo e($matakuliah->nama); ?>

            </option>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['matakuliah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-6">
      <label class="block text-sm text-gray-700" for="matakuliah_id">
        NIP <span class="text-xs text-gray-500">(Boleh Kosong)</span>
      </label>
      <input
        class="w-full px-5 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 focus:border-gray-800
      <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        id="nip" name="nip" type="text" placeholder="NIP Dosen" aria-label="NIP"
        value="<?php echo e(old('nip', $dosen->nip)); ?>">
      <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-6">
      <label class="block text-sm text-gray-700" for="foto">Foto</label>
      <input type="hidden" name="oldFoto" value="<?php echo e($dosen->foto); ?>">

      <?php if($dosen->foto): ?>
        <div class="w-24 mb-1">
          <div class="aspect-h-4 aspect-w-3 img-container">
            <img src="<?php echo e(asset('storage/' . $dosen->foto)); ?>"
              class="img-preview mb-2 object-center object-cover">
          </div>
        </div>
      <?php else: ?>
        <div class="w-24 mb-1">
          <div class="aspect-h-4 aspect-w-3 hidden img-container">
            <img
              class="img-preview border border-gray-700 mb-2 object-center object-cover">
          </div>
        </div>
      <?php endif; ?>

      <input onchange="previewImg()"
        class="img-input w-full px-0 py-1 text-gray-800 bg-gray-200 rounded outline-none border-2 border-gray-200 focus:border-gray-800 <?php $__errorArgs = ["
      foto"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto" type="file">
    <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <span class="text-xs font-bold text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  <div class="flex gap-3">
    <button
      class="px-4 py-1 text-white font-light tracking-wider bg-blue-600 hover:bg-blue-500 rounded"
      type="submit">Simpan Perubahan</button>

    <a href="<?php echo e(route('admin.dosen.index')); ?>"
      class="px-4 py-1 text-white font-light tracking-wider bg-gray-700 hover:bg-gray-600 rounded">Batal</a>
  </div>
</form>

<form action="<?php echo e(route('admin.dosen.destroy', $dosen)); ?>" method="post">
  <?php echo method_field("delete"); ?>
  <?php echo csrf_field(); ?>

  <button onclick="return confirm('Anda Yakin Ingin Menghapus ?')"
    class="bg-red-500 text-white font-semibold py-2 px-3 rounded-br-md rounded-bl-md rounded-tr-md shadow hover:shadow-lg hover:bg-red-400">
    <i class="fas fa-trash mr-3"></i> Hapus Data Dosen
  </button>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('js/imagePreview.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/dosen/edit.blade.php ENDPATH**/ ?>