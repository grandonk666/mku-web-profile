

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("dosen-hero.jpg"),
  "keywords" => "mku, dosen, upn, jatim",
  "description" => "Data Dosen Matakuliah Umum Universitas Pembangunan Nasional
  Veteran Jawa Timur"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => "Data Dosen",
  "image" => asset("dosen-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="container mx-auto min-h-screen py-12 px-4">
    <div class="mb-10">
      <?php echo $__env->make("partials.section-title", ["text" => "Data Dosen MKU"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="flex justify-between md:px-6 items-center flex-wrap gap-10">
      <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('partials.matakuliah-card', [
        'route' => route('dosen.show', $matakuliah),
        'headerText' => 'Dosen',
        'bodyText' => $matakuliah->nama,
        'icon' => 'fa-user-tie'
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/dosen/index.blade.php ENDPATH**/ ?>