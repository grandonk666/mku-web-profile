

<?php $__env->startSection("content"); ?>

<h1 class="text-3xl text-black pb-5">Data Dosen</h1>

<button class="bg-blue-700 text-blue-100 font-semibold py-2 px-3 rounded-br-lg rounded-bl-lg rounded-tr-lg shadow-lg hover:shadow-xl hover:bg-blue-600 flex items-center justify-center mb-5">
  <i class="fas fa-plus mr-3"></i> Tambah Data Dosen
</button>

<table class="min-w-full bg-white">
  <thead class="bg-gray-800 text-white">
    <tr>
      <th class="w-1/5 text-left py-3 px-4 uppercase font-semibold text-sm">Foto</th>
      <th class="w-1/5 text-left py-3 px-4 uppercase font-semibold text-sm">Nama</th>
      <th class="w-1/5 text-left py-3 px-4 uppercase font-semibold text-sm">Jabatan</th>
      <th class="w-1/5 text-left py-3 px-4 uppercase font-semibold text-sm">NIP</td>
      <th class="w-1/5 text-left py-3 px-4 uppercase font-semibold text-sm">Action</td>
    </tr>
  </thead>
  <tbody class="text-gray-700">
    <tr class="border border-gray-300">
      <td class="w-1/5 text-left pl-4 pr-24 py-4">
        <img src="https://source.unsplash.com/900x1200/?person" alt="">
      </td>
      <td class="w-1/5 text-left py-3 px-4">Smith</td>
      <td class="w-1/5 text-left py-3 px-4">Koordinator</td>
      <td class="w-1/5 text-left py-3 px-4">622322662</td>
      <td class="w-1/5 text-left py-3 px-4">
        <button class="bg-blue-400 hover:bg-blue-300 py-2 px-3 rounded text-white mr-3"><i class="fas fa-eye"></i></button>
        <button class="bg-red-600 hover:bg-red-500 py-2 px-3 rounded text-white"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/dosen.blade.php ENDPATH**/ ?>