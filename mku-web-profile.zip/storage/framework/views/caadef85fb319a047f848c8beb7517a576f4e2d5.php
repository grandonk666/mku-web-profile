<script>
  (function() {
    // var HOST = "http://localhost:8000/upload"; //pass the route

    addEventListener("trix-attachment-add", function(event) {
      if (event.attachment.file) {
        uploadFileAttachment(event.attachment)
      }
    })

    addEventListener("trix-attachment-remove", function(event) {
      deleteAttachment(event);
    })

    function uploadFileAttachment(attachment) {
      uploadFile(attachment.file, setProgress, setAttributes)

      function setProgress(progress) {
        attachment.setUploadProgress(progress)
      }

      function setAttributes(attributes) {
        attachment.setAttributes(attributes)
      }
    }

    function uploadFile(file, progressCallback, successCallback) {
      const token = "<?php echo e(csrf_token()); ?>"
      const uploadEndpoint = '<?php echo e(route('admin.attachment.add')); ?>'
      var formData = createFormData(file);
      var xhr = new XMLHttpRequest();

      xhr.open("POST", uploadEndpoint, true);
      xhr.setRequestHeader('X-CSRF-TOKEN', token);
      xhr.setRequestHeader("Accept", "application/json");

      xhr.upload.addEventListener("progress", function(event) {
        var progress = event.loaded / event.total * 100
        progressCallback(progress)
      })

      xhr.addEventListener("load", function(event) {
        const data = JSON.parse(xhr.responseText);
        var attributes = {
          url: data.url,
          href: data.url
        }

        <?php if(!isset($model_type)): ?>
          createHTMLInput(data.filename)
        <?php endif; ?>

        successCallback(attributes)
      })

      xhr.send(formData)
    }

    function createHTMLInput(value) {
      const form = document.querySelector("#form");
      const input = document.createElement("input");

      input.type = "hidden"
      input.name = "attachments[]"
      input.value = value

      form.appendChild(input);
    }

    function removeHTMLInput(value) {
      const input = document.querySelector(`input[value='${value}']`);
      if (input) {
        input.remove();
      }
    }

    function createFormData(file) {
      var data = new FormData()
      data.append("Content-Type", file.type)
      data.append("file", file)

      <?php if(isset($model_id)): ?>
        data.append("model_id", '<?php echo e($model_id); ?>')
      <?php endif; ?>
      <?php if(isset($model_type)): ?>
        data.append("model_type", '<?php echo e($model_type); ?>')
      <?php endif; ?>

      return data
    }

    function deleteAttachment(event) {
      const token = "<?php echo e(csrf_token()); ?>"
      const deleteEndpoint = '<?php echo e(route('admin.attachment.remove')); ?>'
      console.log(event.attachment);
      let attachment = event.attachment;

      let url = attachment.attachment.attributes.values.url.split('/');
      console.log(url)
      // console.log(`${url[1]}/${url[2]}`);
      let previewURL = `${url[4]}/${url[5]}`;

      if (previewURL && deleteEndpoint) {
        let form = new FormData;
        form.append('image', previewURL);

        <?php if(isset($model_id)): ?>
          form.append("model_id", '<?php echo e($model_id); ?>')
        <?php endif; ?>
        <?php if(isset($model_type)): ?>
          form.append("model_type", '<?php echo e($model_type); ?>')
        <?php endif; ?>

        xhr = new XMLHttpRequest;
        xhr.open('POST', deleteEndpoint, true);
        xhr.setRequestHeader('X-CSRF-Token', token);

        xhr.upload.onprogress = function(event) {
          var progress = event.loaded / event.total * 101;
          return attachment.setUploadProgress(progress);
        };

        xhr.onload = function() {
          if (this.status >= 200 && this.status < 300) {
            var data = JSON.parse(this.responseText);
            console.log(data.filename)

            <?php if(!isset($model_type)): ?>
              removeHTMLInput(data.filename)
            <?php endif; ?>
            return '';
          }
        };

        return xhr.send(form);
      }
    }
  })();
</script>
<?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/attachment-script.blade.php ENDPATH**/ ?>