

<?php $__env->startSection("content"); ?>

<a href="<?php echo e(route("admin.post.create")); ?>"
  class="bg-blue-700 text-white font-semibold py-2 px-3 rounded-br-md rounded-bl-md rounded-tr-md shadow hover:shadow-lg hover:bg-blue-600">
  <i class="fas fa-plus mr-3"></i> Tambah Post
</a>

<?php if(session()->has("success")): ?>
<div class="w-full bg-green-200 py-3 px-3 text-green-900 mt-6 rounded">
  <?php echo e(session("success")); ?>

</div>
<?php endif; ?>

<div
  class="w-full md:w-1/2 flex flex-col md:flex-row items-start md:items-center justify-between mt-6 gap-4">
  <form action="<?php echo e(route("admin.post.index")); ?>"
    class="w-full md:w-auto flex items-center bg-white rounded-md border border-gray-500">
    <?php if(request("kategori")): ?>
    <input type="hidden" name="kategori" value="<?php echo e(request("kategori")); ?>">
    <?php endif; ?>
    <div class="w-full">
      <input type="text" name="search" value="<?php echo e(request("search")); ?>"
        class="w-full px-4 py-2 text-gray-900 rounded-md focus:outline-none"
        placeholder="Cari">
    </div>
    <div>
      <button type="submit"
        class="flex items-center justify-center w-10 h-10 text-gray-100 rounded-md bg-gray-500">
        <svg class="w-5 h-5" fill="none" stroke="currentColor"
          viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
        </svg>
      </button>
    </div>
  </form>

  <button onclick="togleDropdown()"
    class="relative px-4 py-1 bg-white rounded-md border border-gray-500">
    <span class="text-lg">Kategori</span>
    <i class="fas fa-angle-down ml-2"></i>
    <div
      class="dropdown-menu hidden left-0 top-10 absolute w-40 bg-white rounded-lg shadow-lg py-1 border border-gray-500">
      <a href="<?php echo e(route("admin.post.index", ["kategori" => "berita"])); ?>"
        class="block py-2 hover:bg-gray-700 hover:text-white <?php echo e(request('kategori') == 'berita' ? 'bg-gray-700 text-white' : ''); ?>">
        Berita
      </a>
      <a href="<?php echo e(route("admin.post.index", ["kategori" => "pengumuman"])); ?>"
        class="block py-2 hover:bg-gray-700 hover:text-white <?php echo e(request('kategori') == 'pengumuman' ? 'bg-gray-700 text-white' : ''); ?>">
        Pengumuman
      </a>
      <a href="<?php echo e(route("admin.post.index")); ?>"
        class="block py-2 hover:bg-gray-700 hover:text-white">
        Tampilkan Semua
      </a>
    </div>
  </button>
</div>

<?php if($posts->isEmpty()): ?>
<h2 class="text-2xl mt-4">Data Tidak Ditemukan</h2>
<?php else: ?>
<div
  class="shadow-md overflow-hidden border-b border-gray-200 rounded-md w-full my-4">
  <table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-300">
      <tr>
        <th scope="col"
          class="w-1/5 px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider hidden md:table-cell">
          Sampul
        </th>
        <th scope="col"
          class="md:w-1/3 px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
          Judul
        </th>
        <th scope="col"
          class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
          Kategori
        </th>
        <th scope="col"
          class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider  hidden md:table-cell">
          Tanggal
        </th>
      </tr>
    </thead>
    <tbody class="bg-white divide-y divide-gray-200">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr onclick="location.href='<?php echo e(route("admin.post.edit", $post)); ?>'"
        class="cursor-pointer hover:bg-gray-100">
        <?php if($post->sampul): ?>
        <td class="w-1/5 px-6 py-4 whitespace-nowrap hidden md:table-cell">
          <div class="aspect-w-16 aspect-h-9">
            <img src="<?php echo e(asset("storage/".$post->sampul)); ?>"
              alt="<?php echo e($post->judul); ?>"
              class="w-full object-center object-cover" />
          </div>
        </td>
        <?php else: ?>
        <td class="w-1/5 px-6 py-4 whitespace-nowrap hidden md:table-cell">
          <div class="aspect-w-16 aspect-h-9">
            <img src="<?php echo e(asset("storage/sampul-post/sampul-default.jpg")); ?>"
              alt="<?php echo e($post->judul); ?>"
              class="w-full object-center object-cover" />
          </div>
        </td>
        <?php endif; ?>
        <td class="md:w-1/3 px-6 py-4">
          <div class="text-sm text-gray-900"><?php echo e($post->judul); ?></div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
          <span
            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            <?php echo e($post->kategori->nama); ?>

          </span>
        </td>
        <td
          class="px-6 py-4 whitespace-nowrap text-sm text-gray-500  hidden md:table-cell">
          <?php echo e($post->created_at->format('d, M Y')); ?>

        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php echo e($posts->links()); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/post/index.blade.php ENDPATH**/ ?>