

<?php $__env->startSection("meta"); ?>

<?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("struktur-hero.jpg"),
  "keywords" => "mku, struktur organisasi, organisasi, upn, jatim",
  "description" => "Struktur Organisasi Matakuliah Umum Universitas Pembangunan Nasional Veteran Jawa Timur"
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<?php echo $__env->make("partials.hero-section", [
  "text" => "Struktur Organisasi",
  "image" => asset("struktur-hero.jpg")
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="container mx-auto min-h-screen py-12 px-4">
  <div class="mb-10">
    <?php echo $__env->make("partials.section-title", ["text" => "Struktur Organisasi"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  
  <?php echo $__env->make("partials.foto-dosen", [
    "dosen" => $koordinator->dosen,
    "width" => "w-11/12 md:w-1/3",
    "jabatan" => $koordinator->jabatan
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="flex justify-center items-center flex-wrap gap-8">
    <?php $__currentLoopData = $listStruktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $struktur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo $__env->make("partials.foto-dosen", [
        "dosen" => $struktur->dosen,
        "width" => "w-11/12 md:w-[28%]",
        "jabatan" => $struktur->jabatan
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/struktur.blade.php ENDPATH**/ ?>