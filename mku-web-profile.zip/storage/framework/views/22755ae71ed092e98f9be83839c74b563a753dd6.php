

<?php $__env->startSection('content'); ?>

  <a href="<?php echo e(route('admin.dosen.create')); ?>"
    class="bg-blue-700 text-white font-semibold py-2 px-3 rounded-br-md rounded-bl-md rounded-tr-md shadow hover:shadow-lg hover:bg-blue-600">
    <i class="fas fa-plus mr-3"></i> Tambah Data Dosen
  </a>

  <?php if(session()->has('success')): ?>
    <div class="w-full bg-green-200 py-3 px-3 text-green-900 mt-6 rounded">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <div
    class="shadow-md overflow-hidden border-b border-gray-200 rounded-md w-full mt-4">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-300">
        <tr>
          <th scope="col"
            class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
            Nama
          </th>
          <th scope="col"
            class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider hidden md:table-cell">
            Jabatan
          </th>
          <th scope="col"
            class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
            Matakuliah
          </th>
          <th scope="col"
            class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider hidden md:table-cell">
            NIP
          </th>
        </tr>
      </thead>
      <tbody class="bg-white divide-y divide-gray-200">
        <?php $__currentLoopData = $listDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr onclick="location.href='<?php echo e(route('admin.dosen.edit', $dosen)); ?>'"
            class="cursor-pointer hover:bg-gray-100">
            <td class="px-6 py-4">
              <div class="flex items-center">
                <div class="hidden md:block flex-shrink-0 h-10 w-10">
                  <?php if($dosen->foto): ?>
                    <img class="h-10 w-10 rounded-full object-cover"
                      src="<?php echo e(asset('storage/' . $dosen->foto)); ?>"
                      alt="<?php echo e($dosen->nama); ?>">
                  <?php else: ?>
                    <img class="h-10 w-10 rounded-full object-cover"
                      src="<?php echo e(asset('storage/foto-dosen/foto-default.jpg')); ?>"
                      alt="<?php echo e($dosen->nama); ?>">
                  <?php endif; ?>
                </div>
                <div class="md:ml-4">
                  <div class="text-sm font-medium text-gray-900">
                    <?php echo e($dosen->nama); ?>

                  </div>
                </div>
              </div>
            </td>
            <td class="px-6 py-4 hidden md:table-cell">
              <div class="text-sm text-gray-900">
                <?php if($dosen->struktur): ?>
                  <?php echo e($dosen->struktur->jabatan); ?>

                <?php else: ?>
                  Dosen Reguler
                <?php endif; ?>
              </div>
            </td>
            <td class="px-6 py-4 text-sm text-gray-500">
              <?php if($dosen->matakuliah): ?>
                <?php echo e($dosen->matakuliah->nama); ?>

              <?php else: ?>
                Kosong
              <?php endif; ?>
            </td>
            <td class="px-6 py-4 text-sm text-gray-500 hidden md:table-cell">
              <?php if($dosen->nip): ?>
                <?php echo e($dosen->nip); ?>

              <?php else: ?>
                Kosong
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/dosen/index.blade.php ENDPATH**/ ?>