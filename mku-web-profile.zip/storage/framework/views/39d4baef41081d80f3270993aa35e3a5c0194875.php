<title><?php echo e($title); ?> | MKU</title>
<meta property="og:title" content="<?php echo e($title); ?> | MKU" />
<meta name="twitter:title" content="<?php echo e($title); ?> | MKU" />

<meta name="description"
  content="<?php echo e($description); ?>">
<meta property="og:description"
  content="<?php echo e($description); ?>" />
<meta name="twitter:description"
  content="<?php echo e($description); ?>" />

<meta name="image" content="<?php echo e($image); ?>" />
<meta property="og:image" content="<?php echo e($image); ?>" />
<meta name="twitter:image" content="<?php echo e($image); ?>" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:site" content="@site" />
<meta name="twitter:creator" content="@handle" />

<meta property="og:url" content=<?php echo e(Request::fullUrl()); ?> />
<meta property="og:site_name" content='MKU UPN "Veteran" Jawa Timur' />

<meta name="keywords"
  content="<?php echo e($keywords); ?>" />
<link rel="canonical" href="<?php echo e(Request::fullUrl()); ?>" />

<?php if(isset($article)): ?>
<meta property="og:type" content="article" />
<?php endif; ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/partials/site-meta.blade.php ENDPATH**/ ?>