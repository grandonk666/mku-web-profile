

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('admin.matakuliah.create')); ?>"
        class="bg-blue-700 text-white font-semibold py-2 px-3 rounded-br-md rounded-bl-md rounded-tr-md shadow hover:shadow-lg hover:bg-blue-600">
        <i class="fas fa-plus mr-3"></i> Tambah Data Matakuliah
    </a>

    <?php if(session()->has('success')): ?>
        <div class="w-full bg-green-200 py-3 px-3 text-green-900 mt-6 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="shadow-md overflow-hidden border-b border-gray-200 rounded-md w-full mt-4">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-300">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">
                        Nama Matakuliah
                    </th>
                    <th scope="col"
                        class="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider hidden md:table-cell">
                        Dosen Pengajar
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $listMatakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr onclick="location.href='<?php echo e(route('admin.matakuliah.edit', $matakuliah)); ?>'"
                        class="cursor-pointer hover:bg-gray-100">
                        <td class="px-6 py-4">
                            <?php echo e($matakuliah->nama); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500">
                            <ul class="list-disc">
                                <?php $__empty_1 = true; $__currentLoopData = $matakuliah->listDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li class="py-1">
                                        <?php echo e($dosen->nama); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li>
                                        Belum ada dosen pengajar
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/admin/matakuliah/index.blade.php ENDPATH**/ ?>