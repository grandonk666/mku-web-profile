<div class="<?php echo e($width); ?> mx-auto p-3 bg-white rounded shadow-md mb-8">
  <div class="aspect-h-10 aspect-w-9 rounded overflow-hidden mb-4">
    <?php if($dosen->foto): ?>
    <img src="<?php echo e(asset("storage/".$dosen->foto)); ?>"
      alt="<?php echo e($dosen->nama); ?>"
      class="img-preview mb-2 object-center object-cover">
    <?php else: ?>
    <img src="<?php echo e(asset("storage/foto-dosen/foto-default.jpg")); ?>"
      alt="<?php echo e($dosen->nama); ?>"
      class="img-preview mb-2 object-center object-cover">
    <?php endif; ?>
  </div>
  <div class="px-2">
    <p class="text-xl font-bold"><?php echo e($dosen->nama); ?></p>
    <?php if(isset($jabatan)): ?>
    <span class="text-sm text-gray-700"> - <?php echo e($jabatan); ?></span>
    <?php endif; ?>
  </div>
</div><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/partials/foto-dosen.blade.php ENDPATH**/ ?>