<?php if($paginator->hasPages()): ?>
<nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>"
    class="flex items-center justify-between">
    <div class="flex justify-between flex-1 md:hidden">
        <?php if($paginator->onFirstPage()): ?>
        <span
            class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-500 cursor-default leading-5 rounded-full">
            <?php echo e("<< Mundur"); ?>

        </span>
        <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>"
            class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-500 leading-5 rounded-full hover:text-gray-500 focus:outline-none focus:ring ring-gray-300 focus:border-gray-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
            <?php echo e("<< Mundur"); ?>

        </a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>"
            class="relative inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-gray-700 bg-white border border-gray-500 leading-5 rounded-full hover:text-gray-500 focus:outline-none focus:ring ring-gray-300 focus:border-gray-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150">
            <?php echo e("Lanjut >>"); ?>

        </a>
        <?php else: ?>
        <span
            class="relative inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-gray-500 bg-white border border-gray-500 cursor-default leading-5 rounded-full">
            <?php echo e("Lanjut >>"); ?>

        </span>
        <?php endif; ?>
    </div>

    <div class="hidden md:flex-1 md:flex md:items-center md:justify-between">
        <div>
            <span class="relative z-0 inline-flex shadow-sm rounded-full">
                
                <?php if($paginator->onFirstPage()): ?>
                <span aria-disabled="true"
                    aria-label="<?php echo e(__('pagination.previous')); ?>">
                    <span
                        class="relative inline-flex items-center px-2 py-2 text-sm font-medium text-gray-700 bg-white cursor-default rounded-full leading-5 mr-2 border border-gray-500"
                        aria-hidden="true">
                        <svg class="w-5 h-5" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                clip-rule="evenodd" />
                        </svg>
                    </span>
                </span>
                <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"
                    class="relative inline-flex items-center px-2 py-2 text-sm font-medium text-gray-700 bg-white rounded-full leading-5 hover:text-gray-400 focus:z-10 focus:outline-none focus:ring ring-gray-300 focus:border-gray-300 active:bg-gray-100 active:text-gray-500 transition ease-in-out duration-150 mr-2 border border-gray-500"
                    aria-label="<?php echo e(__('pagination.previous')); ?>">
                    <svg class="w-5 h-5" fill="currentColor"
                        viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                            clip-rule="evenodd" />
                    </svg>
                </a>
                <?php endif; ?>

                <div
                    class="inline-flex rounded-full overflow-hidden bg-white lining-nums border border-gray-500">
                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(is_string($element)): ?>
                    <span aria-disabled="true">
                        <span
                            class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white cursor-default leading-5"><?php echo e($element); ?></span>
                    </span>
                    <?php endif; ?>

                    
                    <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                    <span aria-current="page">
                        <span
                            class="relative inline-flex items-center px-4 py-2 rounded-full text-sm font-medium text-gray-200 bg-gray-600 cursor-default leading-5"><?php echo e($page); ?></span>
                    </span>
                    <?php else: ?>
                    <a href="<?php echo e($url); ?>"
                        class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white leading-5 hover:text-gray-400 focus:z-10 focus:outline-none focus:ring ring-gray-300 focus:border-gray-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150 rounded-full"
                        aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>">
                        <?php echo e($page); ?>

                    </a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"
                    class="relative inline-flex items-center px-2 py-2 ml-2 text-sm font-medium text-gray-700 bg-white rounded-full leading-5 hover:text-gray-400 focus:z-10 focus:outline-none focus:ring ring-gray-300 focus:border-gray-300 active:bg-gray-100 active:text-gray-500 transition ease-in-out duration-150 border border-gray-500"
                    aria-label="<?php echo e(__('pagination.next')); ?>">
                    <svg class="w-5 h-5" fill="currentColor"
                        viewBox="0 0 20 20">
                        <path fill-rule="evenodd"
                            d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                            clip-rule="evenodd" />
                    </svg>
                </a>
                <?php else: ?>
                <span aria-disabled="true"
                    aria-label="<?php echo e(__('pagination.next')); ?>">
                    <span
                        class="relative inline-flex items-center px-2 py-2 ml-2 text-sm font-medium text-gray-500 bg-white cursor-default rounded-full leading-5 border border-gray-500"
                        aria-hidden="true">
                        <svg class="w-5 h-5" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                clip-rule="evenodd" />
                        </svg>
                    </span>
                </span>
                <?php endif; ?>
            </span>
        </div>
    </div>
</nav>
<?php endif; ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>