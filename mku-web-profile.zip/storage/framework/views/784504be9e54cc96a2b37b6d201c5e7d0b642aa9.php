

<?php $__env->startSection('meta'); ?>

  <?php echo $__env->make("partials.site-meta", [
  "title" => $title,
  "image" => asset("posts-hero.jpg"),
  "keywords" => "mku, berita, pengumuman, upn, jatim",
  "description" => "Berita dan Pengumuman Matakuliah Umum Universitas Pembangunan
  Nasional Veteran Jawa Timur"
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make("partials.hero-section", [
  "text" => "Berita & Pengumuman",
  "image" => asset("posts-hero.jpg")
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main class="container mx-auto min-h-screen py-12 px-4">
    <div class="w-full flex justify-between flex-wrap items-center mb-8">
      <div class="mb-4">
        <?php echo $__env->make("partials.section-title", ["text" => "Berita & Pengumunan"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <div
        class="w-full md:w-1/2 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <form action="<?php echo e(route('post.index')); ?>"
          class="w-full md:w-2/3 flex items-center bg-white rounded-md border border-gray-500">
          <?php if(request('kategori')): ?>
            <input type="hidden" name="kategori"
              value="<?php echo e(request('kategori')); ?>">
          <?php endif; ?>
          <div class="w-full">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
              class="w-full px-4 py-2 text-gray-900 rounded-md focus:outline-none"
              placeholder="Cari">
          </div>
          <div>
            <button type="submit"
              class="flex items-center justify-center w-10 h-10 text-gray-100 rounded-md bg-gray-500">
              <svg class="w-5 h-5" fill="none" stroke="currentColor"
                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round"
                  stroke-width="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z">
                </path>
              </svg>
            </button>
          </div>
        </form>

        <button onclick="togleDropdown()"
          class="relative px-4 py-1 bg-white rounded-md border border-gray-500">
          <span class="text-lg">Kategori</span>
          <i class="fas fa-angle-down ml-2"></i>
          <div
            class="dropdown-menu hidden left-0 top-10 absolute w-40 bg-white rounded-md shadow-md py-1 border border-gray-500">
            <a href="<?php echo e(route('post.index', ['kategori' => 'berita'])); ?>"
              class="block py-2 px-2 hover:bg-gray-700 hover:text-white <?php echo e(request('kategori') == 'berita' ? 'bg-gray-700 text-white' : ''); ?>">
              Berita
            </a>
            <a href="<?php echo e(route('post.index', ['kategori' => 'pengumuman'])); ?>"
              class="block py-2 px-2 hover:bg-gray-700 hover:text-white <?php echo e(request('kategori') == 'pengumuman' ? 'bg-gray-700 text-white' : ''); ?>">
              Pengumuman
            </a>
            <a href="<?php echo e(route('post.index')); ?>"
              class="block py-2 px-2 hover:bg-gray-700 hover:text-white">
              Tampilkan Semua
            </a>
          </div>
        </button>
      </div>
    </div>

    <div class="flex justify-center items-stretch flex-wrap gap-10 mb-4">
      <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="flex flex-col rounded shadow-md max-w-sm">
          <div class="flex-shrink-0">
            <?php if($post->sampul): ?>
              <img class="h-48 w-full object-cover"
                src="<?php echo e(asset('storage/' . $post->sampul)); ?>"
                alt="<?php echo e($post->judul); ?>" />
            <?php else: ?>
              <img class="h-48 w-full object-cover"
                src="<?php echo e(asset('storage/sampul-post/sampul-default.jpg')); ?>"
                alt="<?php echo e($post->judul); ?>" />
            <?php endif; ?>
          </div>
          <div class="flex-1 bg-white p-6 flex flex-col justify-between">
            <div class="flex-1">
              <p class="text-sm leading-5 font-medium text-blue-600 uppercase">
                <a href="<?php echo e(route('post.index', ['kategori' => $post->kategori->slug])); ?>"
                  class="hover:underline">
                  <?php echo e($post->kategori->nama); ?>

                </a>
              </p>
              <a href="<?php echo e(route('post.show', $post)); ?>" class="block">
                <h3 class="mt-2 text-xl leading-7 font-semibold text-gray-900">
                  <?php echo e($post->judul); ?>

                </h3>
                <p class="mt-3 text-base leading-6 text-gray-500">
                  <?php echo e($post->excerpt); ?>

                </p>
              </a>
            </div>
            <div class="mt-2">
              <a class="text-blue-400 hover:text-blue-900 text-sm transition duration-150 ease-in-out group"
                href="<?php echo e(route('post.show', $post)); ?>">Lanjut Baca
                <svg
                  class="group-hover:hidden inline-block ml-1 w-2 h-2 stroke-2 stroke-current"
                  viewBox="0 0 10 10" fill="none" aria-hidden="true">
                  <g fill-rule="evenodd">
                    <path d="M1 1l4 4-4 4"></path>
                  </g>
                </svg>
                <svg
                  class="hidden group-hover:inline-block ml-1 w-2 h-2 stroke-2 stroke-current"
                  viewBox="0 0 10 10" fill="none" aria-hidden="true">
                  <g fill-rule="evenodd">
                    <path d="M0 5h7"></path>
                    <path d="M4 1l4 4-4 4"></path>
                  </g>
                </svg>
              </a>
            </div>
            <div class="mt-6 flex items-center">
              <div class="flex text-sm leading-5 text-gray-500 lining-nums">
                <time datetime="<?php echo e($post->created_at->format('Y-m-d')); ?>">
                  <?php echo e($post->created_at->format('d M Y')); ?>

                </time>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2 class="text-4xl font-bold text-center">Tidak Ditemukan</h2>
      <?php endif; ?>
    </div>
    <?php echo e($posts->links()); ?>


  </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/posts/index.blade.php ENDPATH**/ ?>