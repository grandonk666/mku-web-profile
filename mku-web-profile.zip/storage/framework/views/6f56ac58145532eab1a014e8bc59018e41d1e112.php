

<?php $__env->startSection("content"); ?>

<div
  class="fixed inset-0 overflow-hidden bg-gray-600 grid place-content-center z-50">
  <div class="w-24 h-24 border-8 border-gray-500 rounded-full animate-spin"
    style="border-top-color: white">
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programing\laravel\mku-web-profile\resources\views/preloader.blade.php ENDPATH**/ ?>