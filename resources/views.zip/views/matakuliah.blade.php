@extends("layouts.main")

@section("meta")

<title>{{ $title }} | MKU</title>
<meta property="og:title" content="{{ $title }} | MKU" />
<meta name="twitter:title" content="{{ $title }} | MKU" />

<meta name="description"
  content="Data Matakuliah yang ada di Matakuliah Umum Universitas Pembangunan Nasional Veteran Jawa Timur">
<meta property="og:description"
  content="Data Matakuliah yang ada di Matakuliah Umum Universitas Pembangunan Nasional Veteran Jawa Timur" />
<meta name="twitter:description"
  content="Data Matakuliah yang ada di Matakuliah Umum Universitas Pembangunan Nasional Veteran Jawa Timur" />

<meta name="image" content="{{ asset("matakuliah-hero.jpg") }}" />
<meta property="og:image" content="{{ asset("matakuliah-hero.jpg") }}" />
<meta name="twitter:image" content="{{ asset("matakuliah-hero.jpg") }}" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:site" content="@site" />
<meta name="twitter:creator" content="@handle" />

<meta property="og:url" content={{ Request::fullUrl() }} />
<meta property="og:site_name" content='MKU UPN "Veteran" Jawa Timur' />

<meta name="keywords" content="mku, matakuliah, upn, jatim" />
<link rel="canonical" href="{{ Request::fullUrl() }}" />

@endsection

@section("content")

<div
  class="relative w-full min-h-[70vh] md:min-h-screen flex justify-center items-center bg-cover bg-bottom"
  style="background-image: url({{ asset("matakuliah-hero.jpg") }})">
  <div
    class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent bg-black/20 flex justify-center items-center flex-col">
    <div
      class="bg-black/80 flex justify-center items-center  w-11/12 lg:w-4/5 py-12">
      <h1 class="text-4xl lg:text-6xl font-bold text-white text-center">Data
        Matakuliah</h1>
    </div>
  </div>
</div>

<main class="container mx-auto min-h-screen py-12 px-4">
  <div class="mb-12">
    <span class="block w-40 h-1.5 bg-gray-500 rounded-full mb-2"></span>
    <h2 class="text-gray-900 font-bold text-3xl">Daftar Matakuliah MKU</h2>
  </div>

  <div class="flex justify-between md:px-6 items-center flex-wrap gap-10">
    @foreach ($listMatakuliah as $matakuliah)
    <div
      class="w-full md:w-[45%] px-4 pt-3 pb-2 bg-white rounded shadow-md relative">
      <span
        class="w-16 h-16 rounded-full absolute right-6 -top-8 bg-white flex justify-center items-center border-8 border-gray-100 text-2xl text-gray-700">
        <i class="fas fa-book"></i>
      </span>
      <h2 class="text-xl font-bold py-1 border-b-2 border-gray-200">
        {{ $matakuliah->nama }}</h2>
      <p class="text-gray-700 lining-nums py-1">
        Kode : <span
          class="text-gray-900 font-bold">{{ $matakuliah->kode }}</span>
      </p>
    </div>
    @endforeach
  </div>

</main>

@endsection